<?php

class Complaint_victimsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('complaint_victims')->truncate();

		$complaint_victims = array(

//			["id" => , "complaint_id" =>, "client_id" =>],

		);

		// Uncomment the below to run the seeder
		// DB::table('complaint_victims')->insert($complaint_victims);
	}

}
