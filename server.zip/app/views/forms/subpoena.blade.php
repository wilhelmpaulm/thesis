<html>
<title>
	Subpoena
</title>

<body>

<div id="" style="position:relative; left:100px ">

	<img src="nbi_header.png" height="90" width="380" style="position:absolute; top:5px; left:70px">

	<div id="" style="text-align:left; position:absolute; top:110px; left:195px "> _______________ </div>

	<div id="" style="text-align:left; font-size:30px; position:absolute; top:130px; left:180px "> SUBPOENA</div>

	<div id="" style="text-align:left; position:absolute; top:150px; left:195px "> _______________ </div>

	<div id="" style="text-align:left;  position:absolute; top:200px"> GREETING:</div>

	<div id="" style="text-align:left;  position:absolute; top:230px; left:30px"><i> Under and by virtue of the authority vested in me by Republic Act No. 157,</i></div>

	<div id="" style="text-align:left;  position:absolute; top:255px"><i> you are hereby commanded to be and appear in the</i></div>

	<div id="" style="text-align:left; position:absolute; top:255px; left:342px "> _____________________ </div>

	<div id="" style="text-align:left; position:absolute; top:280px"> _______________________________________________________________ </div>

	<div id="" style="text-align:left; position:absolute; top:305px"> _________________________</div>

	<div id="" style="text-align:left; position:absolute; top:305px; left:210px"> , Philippines, at</div>

	<div id="" style="text-align:left; position:absolute; top:305px; left:303px"> __________________________</div>

	<div id="" style="text-align:left; position:absolute; top:330px">on the </div>

	<div id="" style="text-align:left; position:absolute; top:330px; left:50px"> _________</div>

	<div id="" style="text-align:left; position:absolute; top:330px; left: 130px">day of </div>

	<div id="" style="text-align:left; position:absolute; top:330px; left:173px"> ________________</div>

	<div id="" style="text-align:left; position:absolute; top:330px; left: 303px">, 20</div>

	<div id="" style="text-align:left; position:absolute; top:330px; left:330px"> ____</div>

	<div id="" style="text-align:left; position:absolute; top:330px; left:370px"> <i>then and there to give</i></div>

	<div id="" style="text-align:left; position:absolute; top:355px"> <i>your evidence in a certain investigation to be held at that time and place,</i></div>

	<div id="" style="text-align:left; position:absolute; top:380px"> <i>conducted by the undersigned.</i></div>

	<div id="" style="text-align:left; position:absolute; top:410px; left:30px"> <i>Fail not, under the penalty of the law.</i></div>

	<div id="" style="text-align:left; position:absolute; top:435px; left:30px"> <i>Witness my hand and seal this</i></div>

	<div id="" style="text-align:left; position:absolute; top:435px; left:225px"> ________</div>

	<div id="" style="text-align:left; position:absolute; top:435px; left: 290px">day of </div>

	<div id="" style="text-align:left; position:absolute; top:435px; left:335px"> ______________</div>

	<div id="" style="text-align:left; position:absolute; top:435px; left: 450px">, 20</div>

	<div id="" style="text-align:left; position:absolute; top:435px; left:478px"> ____</div>

	<div id="" style="text-align:left; position:absolute; top:520px; left:300px">By</div>

	<div id="" style="text-align:left; position:absolute; top:520px; left:320px"> ________________________</div>

	<div id="" style="text-align:left; font-size:12px; position:absolute; top:580px">NBI FORM No. 11</div>

</div>

</body>
</html>	