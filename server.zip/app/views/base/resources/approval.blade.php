@extends("layouts.main")

@section("main")

<div class="col-md-12">

    <div class="row">
        <div class="col-md-6">
            @include("sidebar.sub.resources.approval")
        </div>
        <div class="col-md-6">
            
        </div>


    </div>
</div>





@stop