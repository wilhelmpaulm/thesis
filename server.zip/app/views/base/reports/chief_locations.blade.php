@extends("layouts.main")

@section("main")

<div class="col-md-12">

    <div class="row">
        <div class="col-md-12">
            @include("content.reports.chief_locations")
        </div>


    </div>
</div>





@stop