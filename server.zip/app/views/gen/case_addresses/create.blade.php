<div>
    <div class="row ">
        <div class="form-group col-md-4">
            <label for="street">Street</label>
            <input type="text" class="form-control" id="street" placeholder="1671 Pedro Gil St" name="street">
        </div>
        <div class="form-group col-md-4">
            <label for="city">City</label>
            <input type="text" class="form-control" id="city" placeholder="Paco, Manila" name="city">
        </div>
        <div class="form-group col-md-4">
            <label for="city">Barangay</label>
            <input type="text" class="form-control" id="city" placeholder="817" name="barangay">
        </div>
    </div>
    <div class="row ">
        <div class="form-group col-md-4">
            <label for="postal_code">Postal Code</label>
            <input type="number" class="form-control" id="postal_code" placeholder="1007" name="postal_code">
        </div>
        <div class="form-group col-md-4">
            <label for="province">Province</label>
            <input type="text" class="form-control" id="city" placeholder="Nueva Ecija" name="province">
        </div>
    </div>
</div>