<?php

class Resource_historiesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('resource_histories')->truncate();

		$resource_histories = array(

//			["id" => , "resource_id" => , "user_id" =>, "details" =>"", "amount" =>"", "status" =>"", "date_requested" =>"", "date_approved" =>"", "date_due" =>"", "date_issued" =>"", "date_returned" =>""],

		);

		// Uncomment the below to run the seeder
		// DB::table('resource_histories')->insert($resource_histories);
	}

}
