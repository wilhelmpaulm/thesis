<?php

class Message_logsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('message_logs')->truncate();

		$message_logs = array(

//			["id" => , "message_id" => , "user_id" =>, "body" => ""],

		);

		// Uncomment the below to run the seeder
		// DB::table('message_logs')->insert($message_logs);
	}

}
