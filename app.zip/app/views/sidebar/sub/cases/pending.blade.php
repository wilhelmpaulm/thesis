<div class="list-group" >
    <div class="list-group-item ">
        <div class="input-group custom-search-form input-group-sm">
            <input type="text" class="form-control " placeholder="Search...">
            <span class="input-group-btn">
                <button class="btn btn-default " type="button">
                    <i class="glyphicon glyphicon-search"></i>
                </button>
            </span>
        </div>
    </div>
    <div style="height: 450px; overflow-y: scroll">
        <a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a>
        
        <a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a><a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a><a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a><a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a><a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a><a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a><a id="shag" href="#" class="list-group-item ">
            <h4 class="list-group-item-heading">List group item</h4>
            <p class="list-group-item-text">While not always necessary, sometimes you need to put your DOM in a box.</p>
        </a>
        
        

    </div>
</div>

<script>


    $("#shag").on("click", function() {
        $.get("http://localhost:8000/content/1", function(data) {
            $("#content").replaceWith(data);
        });

//            window.history.pushState("#", "Title", window.location+"dashboard/1");

        return false;
    });

</script>
