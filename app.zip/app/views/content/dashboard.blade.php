<div id="content">
    <div class="row">
       
        <div class="col-md-4" style="min-height: 400px">
             <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil fa-fw"></i> Notepad
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <textarea class="form-control"  name="" rows="4" cols="20" style="min-height: 380px"></textarea>
                            <!-- /.list-group -->
                            <br>
                            <a href="#" class="btn btn-default btn-block">Save Changes</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>

            
        </div>
        
        <div class="col-md-4 " style="min-height: 400px">
             <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bell fa-fw"></i> Notifications Panel
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="list-group" style="min-height: 380px">
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-comment fa-fw"></i> New Comment
                                    <span class="pull-right text-muted small"><em>4 minutes ago</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                    <span class="pull-right text-muted small"><em>12 minutes ago</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-envelope fa-fw"></i> Message Sent
                                    <span class="pull-right text-muted small"><em>27 minutes ago</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-tasks fa-fw"></i> New Task
                                    <span class="pull-right text-muted small"><em>43 minutes ago</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                    <span class="pull-right text-muted small"><em>11:32 AM</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-bolt fa-fw"></i> Server Crashed!
                                    <span class="pull-right text-muted small"><em>11:13 AM</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-warning fa-fw"></i> Server Not Responding
                                    <span class="pull-right text-muted small"><em>10:57 AM</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-shopping-cart fa-fw"></i> New Order Placed
                                    <span class="pull-right text-muted small"><em>9:49 AM</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-money fa-fw"></i> Payment Received
                                    <span class="pull-right text-muted small"><em>Yesterday</em>
                                    </span>
                                </a>
                            </div>
                            <!-- /.list-group -->
                            <a href="#" class="btn btn-default btn-block">View All Alerts</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>

            
        </div>
        <div class="col-md-4" >
             <div class="panel panel-default" >
                        <div class="panel-heading">
                            <i class="fa fa-calendar fa-fw"></i> February 6, 2014
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body" >
                            <div class="list-group" style="min-height: 380px">
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-cutlery fa-fw"></i> Eat breakfast
                                    <span class="pull-right text-muted small"><em>7:00 AM</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-clock-o fa-fw"></i> Attend thesis meeting
                                    <span class="pull-right text-muted small"><em>11:00 AM</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-cutlery fa-fw"></i> Have lunch with Janine
                                    <span class="pull-right text-muted small"><em>12:00 PM</em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-clock-o fa-fw"></i> Meeting with Ms. Stef
                                    <span class="pull-right text-muted small"><em>2:00 PM</em>
                                    </span>
                                </a>
                                
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-tasks fa-fw"></i> Design DB (thesis)
                                    <span class="pull-right text-muted small"><em>3:30 PM</em>
                                    </span>
                                </a>
                                
                            </div>
                            <!-- /.list-group -->
                            <a href="#" class="btn btn-default btn-block">View Calendar</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>

            
        </div>



    </div>
</div>