<ul class="dropdown-menu"  id="alert-messages">
    <li>
        <a href="#">
            <div>
                <strong><!--TITLE--></strong>
                <span class="pull-right text-muted">
                    <em><!--DATE--></em>
                </span>
            </div>
            <div><!--BODY--></div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a class="text-center" href="#">
            <strong>Read All Messages</strong>
            <i class="fa fa-angle-right"></i>
        </a>
    </li>
</ul>