<?php

class User_addressesTableSeeder extends Seeder {

    public function run() {
        // Uncomment the below to wipe the table clean before populating
        DB::table('user_addresses')->truncate();

        $user_addresses = array(
            ["user_id" => "10930191", "street" => "1671 Pedro Gil St.", "city" => "manila",
                "postal_code" => "1004", "province" => "manila", "barangay" => "817"],
            ["user_id" => "10930192", "street" => "1671 Pedro Gil St.", "city" => "manila",
                "postal_code" => "1004", "province" => "manila", "barangay" => "817"],
        );

        // Uncomment the below to run the seeder
        DB::table('user_addresses')->insert($user_addresses);
    }

}
