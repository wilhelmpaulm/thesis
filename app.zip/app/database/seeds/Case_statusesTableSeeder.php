<?php

class Case_statusesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('case_statuses')->truncate();

		$case_statuses = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('case_statuses')->insert($case_statuses);
	}

}
