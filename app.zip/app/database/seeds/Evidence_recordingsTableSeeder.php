<?php

class Evidence_recordingsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('evidence_recordings')->truncate();

		$evidence_recordings = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('evidence_recordings')->insert($evidence_recordings);
	}

}
