<?php

class Resource_historiesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('resource_histories')->truncate();

		$resource_histories = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('resource_histories')->insert($resource_histories);
	}

}
