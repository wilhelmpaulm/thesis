<?php

class Client_addressesTableSeeder extends Seeder {

    public function run() {
        // Uncomment the below to wipe the table clean before populating
        DB::table('client_addresses')->truncate();

        $client_addresses = array(
        );

        // Uncomment the below to run the seeder
        DB::table('client_addresses')->insert($client_addresses);
    }

}
