<?php

class Appointment_receipientsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('appointment_receipients')->truncate();

		$appointment_receipients = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('appointment_receipients')->insert($appointment_receipients);
	}

}
