<?php

class Case_victimsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('case_victims')->truncate();

		$case_victims = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('case_victims')->insert($case_victims);
	}

}
