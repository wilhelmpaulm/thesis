<?php

class ClientsTableSeeder extends Seeder {

    public function run() {
        // Uncomment the below to wipe the table clean before populating
         DB::table('clients')->truncate();

        $clients = array(
        );

        // Uncomment the below to run the seeder
         DB::table('clients')->insert($clients);
    }

}
