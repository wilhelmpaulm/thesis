<?php

class Case_subjectsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('case_subjects')->truncate();

		$case_subjects = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('case_subjects')->insert($case_subjects);
	}

}
