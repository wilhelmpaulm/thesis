<?php

class Client_contactsTableSeeder extends Seeder {

    public function run() {
        // Uncomment the below to wipe the table clean before populating
        DB::table('client_contacts')->truncate();

        $client_contacts = array(
        );

        // Uncomment the below to run the seeder
        DB::table('client_contacts')->insert($client_contacts);
    }

}
