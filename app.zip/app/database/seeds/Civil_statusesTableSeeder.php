<?php

class Civil_statusesTableSeeder extends Seeder {

    public function run() {
        // Uncomment the below to wipe the table clean before populating
         DB::table('civil_statuses')->truncate();

        $civil_statuses = array(
            ["status" => "single"],
            ["status" => "married"],
            ["status" => "divorced"],
            ["status" => "widowed"],
            ["status" => "seperated"],
            ["status" => "complicated"],
            
        );

        // Uncomment the below to run the seeder
         DB::table('civil_statuses')->insert($civil_statuses);
    }

}
