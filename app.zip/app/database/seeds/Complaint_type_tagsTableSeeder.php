<?php

class Complaint_type_tagsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('complaint_type_tags')->truncate();

		$complaint_type_tags = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('complaint_type_tags')->insert($complaint_type_tags);
	}

}
