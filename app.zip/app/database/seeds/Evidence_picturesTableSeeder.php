<?php

class Evidence_picturesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('evidence_pictures')->truncate();

		$evidence_pictures = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('evidence_pictures')->insert($evidence_pictures);
	}

}
