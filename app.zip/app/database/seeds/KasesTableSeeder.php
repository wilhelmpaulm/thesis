<?php

class KasesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('kases')->truncate();

		$kases = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('kases')->insert($kases);
	}

}
