<?php

class User_contactsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		 DB::table('user_contacts')->truncate();

		$user_contacts = array(
                    ["user_id"=>"10930191", "type"=>"email", "contact"=>"wilhelmpaulm@gmail.com"],
                    ["user_id"=>"10930191", "type"=>"mobile", "contact"=>"09279655572"],
                    ["user_id"=>"10930192", "type"=>"landline", "contact"=>"5613793"],
                    ["user_id"=>"10930192", "type"=>"email", "contact"=>"soshijang@gmail.com"],
		);

		// Uncomment the below to run the seeder
		 DB::table('user_contacts')->insert($user_contacts);
	}

}
