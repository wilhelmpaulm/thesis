<?php

class UsersTableSeeder extends Seeder {

    public function run() {
        // Uncomment the below to wipe the table clean before populating
        DB::table('users')->truncate();

        $users = array(
            ["id" => "10930191", "last_name" => "Martinez", "first_name" => "Wilhelm Paul",
                "middle_name" => "Bautista", "birthdate" => "1993-02-26", "date_hired" => "2013-01-02",
                "job_title" => "agent", "division" => "fld", "sex" => "male", "password" => Hash::make("pawie2062"),
                "civil_status" => "married"],
            ["id" => "10930192", "last_name" => "Kau", "first_name" => "Janine",
                "middle_name" => "Soshi", "birthdate" => "1993-02-26", "date_hired" => "2013-01-02",
                "job_title" => "secretary", "division" => "fld", "sex" => "female", "password" => Hash::make("pawie2062"),
                "civil_status" => "single"],
        );

        // Uncomment the below to run the seeder
        DB::table('users')->insert($users);
    }

}
