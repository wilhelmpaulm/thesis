<?php

class Case_typesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('case_types')->truncate();

		$case_types = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('case_types')->insert($case_types);
	}

}
